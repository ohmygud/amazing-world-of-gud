GUD — CHARACTER PACK  (2026-10-06)
==============================

Una sola GUD, la stessa di THANK GUD IT'S FRIDAY, in tutte le pose.
One single GUD, the same as THANK GUD IT'S FRIDAY, in every pose.

png/      ogni frame singolo a 1x (34x34 px), 4x e 8x, sfondo trasparente
          every single frame at 1x (34x34 px), 4x and 8x, transparent
svg/      ogni frame come vettoriale a pixel quadrati (scalabile all'infinito)
          every frame as square-pixel vector (scales forever)
sheets/   sprite sheet orizzontali a 1x 2x 4x + JSON con posizione e durata dei frame
          horizontal sprite sheets at 1x 2x 4x + JSON with frame rects and durations
gif/      animazioni pronte (idle, corsa, salto, sparo, vittoria, spiaggia, camminate...)
          ready-made animations (idle, run, jump, shoot, victory, beach, walks...)
palette/  i sei colori in CSS, JSON, GPL, ASE

Nomi: side-* = di profilo (TGIF), front/back/left = vista dall'alto (GUDQUEST),
battle-back = di spalle nelle lotte, beach = costume da spiaggia.

Regola: ingrandisci sempre per multipli interi (2x, 3x, 4x...) con
image-rendering: pixelated, e non fare il logo più grande.
