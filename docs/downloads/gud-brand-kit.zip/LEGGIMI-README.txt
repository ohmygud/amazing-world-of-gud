GUD — BRAND KIT  (2026-10-06)
=========================

fonts/
  GUD Pixel     (OTF, TTF, WOFF, WOFF2)  titoli e interfaccia · titles & UI
                il carattere 5x7 dei giochi, maiuscolo, monospaziato
  VT323         (WOFF2)  testi · body copy — SIL Open Font License
  Press Start 2P (WOFF2) riserva · fallback — SIL Open Font License
  Installa GUD Pixel aprendo il file .otf. Install GUD Pixel by opening the .otf.

palette/   Electric Yellow #FFE600 · Hot Pink #FF1493 · Bubblegum #FF85C8
           Blush #FFD6EA · Ink #111111 · Cream #FFF9F1
           .css (variabili) .json .gpl (GIMP/Aseprite/Inkscape) .ase (Adobe) .png
icons/     tutte le icone del sito e dei giochi, SVG + PNG 1x 2x 4x
           mons = GUDMON, npc = personaggi, bonus/obstacles/bosses/fx = TGIF, ui = interfaccia
character/ GUD in GIF e SVG (il pacchetto completo è gud-character-pack.zip)
guide/     la pagina della guida (apri brand/index.html dal sito per la versione viva)

CSS:
  --pix: 'GUD Pixel', 'Press Start 2P', monospace;
  --body: 'VT323', monospace;
  image-rendering: pixelated;
